const Visitor = require('../models/Visitor');
const nodemailer = require('nodemailer');
const twilio = require('twilio');

exports.register = async (req, res) => {
  const { email, phone } = req.body;
  const newVisitor = new Visitor({ email, phone });
  
  try {
    await newVisitor.save();
    // Enviar e-mail e WhatsApp
    // Configurar nodemailer e Twilio aqui
    res.status(201).send('Visitor registered successfully');
  } catch (error) {
    res.status(500).send('Error registering visitor');
  }
};

exports.list = async (req, res) => {
  const visitors = await Visitor.find();
  res.json(visitors);
};