import { useState, useEffect } from 'react';
import axios from 'axios';

export default function MuseumTotem() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [rating, setRating] = useState(5);
  const [stats, setStats] = useState({ total: 0, average: 0 });

  useEffect(() => {
    axios.get('http://localhost:3000/stats').then(response => {
      setStats(response.data);
    });
  }, []);

  const handleRegister = async () => {
    try {
      await axios.post('http://localhost:3000/register', { name, email, phone });
      alert('Cadastro realizado com sucesso!');
    } catch (error) {
      alert('Erro no cadastro');
    }
  };

  const handleReview = async () => {
    try {
      await axios.post('http://localhost:3000/review', { visitor: name, rating });
      alert('Avaliação registrada!');
    } catch (error) {
      alert('Erro ao enviar avaliação');
    }
  };

  return (
    <div className="p-4 max-w-lg mx-auto">
      <h1 className="text-2xl font-bold mb-4">Totem do Museu</h1>

      <div className="mb-4">
        <input type="text" placeholder="Nome" value={name} onChange={e => setName(e.target.value)} className="border p-2 w-full" />
      </div>
      <div className="mb-4">
        <input type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} className="border p-2 w-full" />
      </div>
      <div className="mb-4">
        <input type="tel" placeholder="Telefone" value={phone} onChange={e => setPhone(e.target.value)} className="border p-2 w-full" />
      </div>
      <button onClick={handleRegister} className="bg-blue-500 text-white p-2 rounded w-full">Cadastrar</button>
      
      <div className="mt-6">
        <h2 className="text-xl font-bold">Avaliação</h2>
        <input type="number" min="0" max="10" value={rating} onChange={e => setRating(Number(e.target.value))} className="border p-2 w-full mt-2" />
        <button onClick={handleReview} className="bg-green-500 text-white p-2 rounded w-full mt-2">Enviar Avaliação</button>
      </div>
      
      <div className="mt-6">
        <h2 className="text-xl font-bold">Estatísticas</h2>
        <p>Total de Avaliações: {stats.total}</p>
        <p>Média: {stats.average}</p>
      </div>
    </div>
  );
}
