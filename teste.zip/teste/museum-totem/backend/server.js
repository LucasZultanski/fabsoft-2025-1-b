const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const nodemailer = require('nodemailer');

const app = express();
app.use(bodyParser.json());
app.use(cors());

// Simulação de banco de dados
let users = [];
let reviews = [];

// Endpoint para cadastro de visitantes
app.post('/register', (req, res) => {
    const { name, email, phone } = req.body;
    if (!name || !email || !phone) {
        return res.status(400).json({ message: 'Todos os campos são obrigatórios!' });
    }
    users.push({ name, email, phone });
    res.status(201).json({ message: 'Cadastro realizado com sucesso!' });
});

// Endpoint para avaliações
app.post('/review', (req, res) => {
    const { visitor, rating } = req.body;
    if (!visitor || rating < 0 || rating > 10) {
        return res.status(400).json({ message: 'Dados inválidos!' });
    }
    reviews.push({ visitor, rating });
    res.status(201).json({ message: 'Avaliação registrada com sucesso!' });
});

// Endpoint para obter estatísticas de avaliações
app.get('/stats', (req, res) => {
    const total = reviews.length;
    const average = total ? (reviews.reduce((sum, r) => sum + r.rating, 0) / total).toFixed(2) : 0;
    res.json({ total, average });
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});
