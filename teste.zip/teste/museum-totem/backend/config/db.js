const mongoose = require('mongoose');
require('dotenv').config();

mongoose.connect(process.env.DB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => console.log('Banco de dados conectado'))
.catch(err => console.error('Erro ao conectar ao banco:', err));
