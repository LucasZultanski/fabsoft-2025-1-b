package br.univille.projfabsofttotemmuseum;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjfabsofttotemmuseumApplicationTests {

	@Test
	void contextLoads() {
	}

}
