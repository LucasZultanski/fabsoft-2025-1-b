package br.univille.projfabsofttotemmuseum;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjfabsofttotemmuseumApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjfabsofttotemmuseumApplication.class, args);
	}

}
